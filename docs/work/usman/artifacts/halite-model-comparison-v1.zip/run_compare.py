"""Run the frozen Halite model comparison after extracting this folder."""
from pathlib import Path
import hashlib
import json
import runpy
import sys
root=Path(__file__).resolve().parent
manifest=json.loads((root/'BUNDLE_MANIFEST.json').read_text())
for name,expected in manifest['files_sha256'].items():
    target=(root/name).resolve()
    if not target.is_relative_to(root) or hashlib.sha256(target.read_bytes()).hexdigest()!=expected:
        raise SystemExit('Bundle file differs from its manifest: '+name)
sys.path.insert(0,str(root))
if any(a=='--packet' or a.startswith('--packet=') for a in sys.argv[1:]):
    raise SystemExit('The portable runner uses its bundled frozen packet; do not replace it.')
sys.argv[1:1]=['--packet',str(Path(__file__).with_name('model_prompts_2024_v1.json'))]
runpy.run_module('investigation.experiments.model_compare',run_name='__main__')
